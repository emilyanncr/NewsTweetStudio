# News Tweet Studio

A local Streamlit application that searches Bing and Google News RSS, drafts title-based X posts with article links, retrieves publisher featured images, and stores approved posts in an Excel queue. Approved rows can be published from the GUI or by the scheduler.

## Start

```bash
chmod +x start.sh
./start.sh
```

The first run creates a Python virtual environment and installs dependencies. Open the local URL shown in the terminal.

## Configure X

Create an X developer project/app with Read and write permissions. Generate OAuth 1.0a user credentials. Copy `.env.example` to `.env`, then fill in:

- `X_API_KEY`
- `X_API_SECRET`
- `X_ACCESS_TOKEN`
- `X_ACCESS_TOKEN_SECRET`

Never share or commit `.env`.

X API use is currently pay-per-usage. Posting and media upload availability depends on the access and credits configured for your developer project.

## Workflow

1. Search a topic such as `"temple elephant" abuse`.
2. Review the article and edit the proposed tweet.
3. Click **Add to Excel queue**. The app attempts to download the publisher's `og:image` or `twitter:image`.
4. Keep **Dry run** enabled for the first test.
5. Process due rows in the GUI or run the scheduler.

## Scheduler

Run once, suitable for cron:

```bash
.venv/bin/python scheduler.py
```

Keep it running:

```bash
.venv/bin/python scheduler.py --daemon --check-every 300
```

Example cron entry to check every 15 minutes:

```cron
*/15 * * * * cd /absolute/path/news_tweet_studio && .venv/bin/python scheduler.py >> scheduler.log 2>&1
```

## Recycling behavior

`POST` rows with a repeat interval are published again as new posts. X does not allow the same account to repost one existing X post repeatedly without first undoing the repost; the app does not automate that spam-like cycle. `REPOST` mode is available for one-time reposts of an external X URL placed in the Article URL column.

## Image limitations

Some publishers block automated page or image requests. The article can still be queued without an image. You can manually supply an Image URL or local Image file in Excel before posting.
