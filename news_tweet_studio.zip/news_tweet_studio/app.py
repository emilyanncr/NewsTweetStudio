from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd
import streamlit as st

from core import (
    DEFAULT_QUEUE,
    add_article_to_queue,
    ensure_directories,
    get_featured_image,
    load_queue_dataframe,
    process_due_rows,
    publish_specific_row,
    search_news,
)

st.set_page_config(page_title="News Tweet Studio", page_icon="🐘", layout="wide")
ensure_directories()

st.title("🐘 News Tweet Studio")
st.caption("Find relevant news, approve a draft, capture its featured image, and place it in an Excel-backed X queue.")

with st.sidebar:
    st.header("Queue settings")
    queue_path = Path(st.text_input("Excel queue", str(DEFAULT_QUEUE))).expanduser()
    default_repeat = st.number_input("Recycle every (days)", min_value=0, max_value=365, value=14)
    default_delay = st.number_input("First post delay (hours)", min_value=0, max_value=720, value=0)
    st.info("0 recycle days means post only once.")

search_tab, queue_tab, setup_tab = st.tabs(["Find news", "Tweet queue", "Setup"])

with search_tab:
    c1, c2, c3 = st.columns([3, 1, 1])
    with c1:
        query = st.text_input("News subject", '"temple elephant" abuse')
    with c2:
        max_results = st.number_input("Results", 1, 30, 10)
    with c3:
        freshness = st.selectbox("Age", ["Any time", "Past day", "Past week", "Past month"], index=2)

    if st.button("Search news", type="primary"):
        with st.spinner("Searching news…"):
            try:
                st.session_state["news_results"] = search_news(query, int(max_results), freshness)
                st.session_state["search_attempted"] = True
            except Exception as exc:
                st.session_state["news_results"] = []
                st.session_state["search_attempted"] = True
                st.error(f"Search failed: {exc}")

    results = st.session_state.get("news_results", [])
    if results:
        st.write(f"Found {len(results)} article(s). Review before adding anything to the queue.")
    elif st.session_state.get("search_attempted"):
        st.warning("No articles were returned. Try fewer quotation marks, a broader phrase, or select Any time.")
    for index, article in enumerate(results):
        with st.container(border=True):
            left, right = st.columns([3, 1])
            with left:
                st.subheader(article["title"])
                st.write(f'{article.get("source", "Unknown source")} · {article.get("published", "Date unavailable")}')
                st.link_button("Open article", article["url"])
                tweet = st.text_area(
                    "Tweet text",
                    value=f'{article["title"]}\n\n{article["url"]}',
                    key=f"tweet_{index}",
                    height=110,
                )
                schedule = datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(hours=int(default_delay))
                if st.button("Add to Excel queue", key=f"add_{index}", type="primary"):
                    with st.spinner("Collecting featured image and saving…"):
                        try:
                            image_url, image_path = get_featured_image(article["url"], article.get("image_url"))
                            row = add_article_to_queue(
                                queue_path=queue_path,
                                title=article["title"],
                                article_url=article["url"],
                                source=article.get("source", ""),
                                published=article.get("published", ""),
                                tweet_text=tweet,
                                image_url=image_url,
                                image_path=image_path,
                                next_run=schedule,
                                repeat_days=int(default_repeat),
                            )
                            st.success(f"Added to Excel row {row}.")
                        except Exception as exc:
                            st.error(f"Could not add article: {exc}")
            with right:
                preview_url = article.get("image_url")
                if preview_url:
                    st.image(preview_url, caption="Feed image", use_container_width=True)
                else:
                    st.caption("The featured image will be checked when you add this article.")

with queue_tab:
    try:
        df = load_queue_dataframe(queue_path)
        if df.empty:
            st.info("The queue is empty.")
        else:
            st.dataframe(df, use_container_width=True, hide_index=True)
            due_count = int(((df["Enabled"].astype(str).str.upper() == "YES") & (df["Status"].astype(str).str.upper().isin(["QUEUED", "RETRY"]))).sum())
            st.caption(f"{due_count} enabled queued/retry item(s); only rows whose Next run time has arrived are processed.")

            c1, c2 = st.columns(2)
            with c1:
                dry_run = st.checkbox("Dry run", value=True)
                if st.button("Process due rows", type="primary"):
                    try:
                        messages = process_due_rows(queue_path, dry_run=dry_run)
                        st.success("\n".join(messages) if messages else "No rows were due.")
                        if not dry_run:
                            st.rerun()
                    except Exception as exc:
                        st.error(str(exc))
            with c2:
                row_number = st.number_input("Publish a specific Excel row", min_value=3, step=1, value=3)
                if st.button("Publish selected row now"):
                    try:
                        message = publish_specific_row(queue_path, int(row_number), dry_run=dry_run)
                        st.success(message)
                        if not dry_run:
                            st.rerun()
                    except Exception as exc:
                        st.error(str(exc))
    except Exception as exc:
        st.error(f"Could not read queue: {exc}")

with setup_tab:
    st.markdown(
        """
### First-time setup

1. Create an X developer project/app and enable **Read and write** access.
2. Generate the four OAuth 1.0a values: API key, API secret, access token, and access-token secret.
3. Copy `.env.example` to `.env` and paste the values there.
4. Launch with `./start.sh`.

### Automation

The GUI works while it is open. For unattended processing, run `scheduler.py` from cron. News discovery remains approval-based: the scheduler publishes approved Excel rows but does not silently approve new articles.

Featured images are obtained from the publisher page's `og:image` or `twitter:image`. Some publishers block automated retrieval; those rows still save and can post without an image, or you can paste an image URL into Excel.
"""
    )
