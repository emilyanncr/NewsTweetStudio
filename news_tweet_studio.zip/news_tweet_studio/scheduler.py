#!/usr/bin/env python3
import argparse
import time
from pathlib import Path

from core import DEFAULT_QUEUE, process_due_rows


def main():
    parser = argparse.ArgumentParser(description="Process approved News Tweet Studio Excel rows")
    parser.add_argument("--queue", default=str(DEFAULT_QUEUE))
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--daemon", action="store_true")
    parser.add_argument("--check-every", type=int, default=300)
    args = parser.parse_args()
    while True:
        messages = process_due_rows(Path(args.queue), dry_run=args.dry_run)
        for message in messages:
            print(message, flush=True)
        if not args.daemon:
            break
        time.sleep(max(30, args.check_every))


if __name__ == "__main__":
    main()

