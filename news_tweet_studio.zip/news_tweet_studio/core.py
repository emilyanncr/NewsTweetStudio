import hashlib
import html
import os
import re
import calendar
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import quote_plus, urljoin, urlparse

import feedparser
import pandas as pd
import requests
from bs4 import BeautifulSoup
from dotenv import load_dotenv
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from PIL import Image

ROOT = Path(__file__).resolve().parent
DEFAULT_QUEUE = ROOT / "data" / "news_tweet_queue.xlsx"
IMAGE_DIR = ROOT / "data" / "images"
SHEET = "Queue"
HEADERS = [
    "Enabled", "Mode", "Status", "Tweet text", "Article URL", "Article title",
    "Source", "Published", "Image URL", "Image file", "Next run (UTC)",
    "Repeat every days", "Last run (UTC)", "Last result", "X Post ID", "Times posted"
]
USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64) NewsTweetStudio/1.0"


def ensure_directories():
    IMAGE_DIR.mkdir(parents=True, exist_ok=True)
    if not DEFAULT_QUEUE.exists():
        create_queue_workbook(DEFAULT_QUEUE)


def create_queue_workbook(path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    ws = wb.active
    ws.title = SHEET
    ws.append(["News Tweet Queue"] + [""] * (len(HEADERS) - 1))
    ws.append(HEADERS)
    ws.freeze_panes = "A3"
    ws.sheet_view.showGridLines = False
    for cell in ws[1]:
        cell.font = Font(bold=True, size=14, color="15202B")
    for cell in ws[2]:
        cell.fill = PatternFill("solid", fgColor="15202B")
        cell.font = Font(bold=True, color="FFFFFF")
        cell.alignment = Alignment(horizontal="center", vertical="center")
    widths = [10, 12, 12, 48, 42, 38, 22, 20, 42, 36, 21, 19, 21, 34, 22, 13]
    for i, width in enumerate(widths, 1):
        ws.column_dimensions[chr(64 + i) if i <= 26 else "A"].width = width
    wb.save(path)


def _freshness_cutoff(freshness):
    days = {"Past day": 1, "Past week": 7, "Past month": 31}.get(freshness)
    return datetime.now(timezone.utc) - timedelta(days=days) if days else None


def search_news(query, max_results=10, freshness="Past week"):
    encoded = quote_plus(query.strip())
    feeds = [
        f"https://www.bing.com/news/search?q={encoded}&format=rss&mkt=en-US",
        f"https://news.google.com/rss/search?q={encoded}&hl=en-US&gl=US&ceid=US:en",
    ]
    cutoff = _freshness_cutoff(freshness)
    results = []
    seen = set()
    failures = []
    for feed_url in feeds:
        try:
            response = requests.get(feed_url, headers={"User-Agent": USER_AGENT}, timeout=20)
            response.raise_for_status()
            feed = feedparser.parse(response.content)
        except Exception as exc:
            failures.append(str(exc))
            continue
        for entry in feed.entries:
            link = entry.get("link", "").strip()
            title = html.unescape(re.sub(r"<[^>]+>", "", entry.get("title", ""))).strip()
            published_parsed = entry.get("published_parsed")
            if cutoff and published_parsed:
                published_dt = datetime.fromtimestamp(calendar.timegm(published_parsed), timezone.utc)
                if published_dt < cutoff:
                    continue
            normalized = re.sub(r"\W+", " ", title.lower()).strip()
            if not link or not title or normalized in seen:
                continue
            seen.add(normalized)
            source_data = entry.get("source", {})
            source = source_data.get("title", "") if hasattr(source_data, "get") else ""
            image_url = ""
            for key in ("media_content", "media_thumbnail"):
                values = entry.get(key, [])
                if values and isinstance(values, list):
                    image_url = values[0].get("url", "")
                    if image_url:
                        break
            if not image_url:
                soup = BeautifulSoup(entry.get("summary", ""), "html.parser")
                tag = soup.find("img")
                image_url = tag.get("src", "") if tag else ""
            results.append({
                "title": title,
                "url": link,
                "source": source or urlparse(link).netloc,
                "published": entry.get("published", ""),
                "image_url": image_url,
            })
            if len(results) >= max_results:
                return results
    if not results and len(failures) == len(feeds):
        raise RuntimeError("Both news providers failed: " + " | ".join(failures))
    return results


def _metadata_image(article_url):
    response = requests.get(article_url, headers={"User-Agent": USER_AGENT}, timeout=20, allow_redirects=True)
    response.raise_for_status()
    soup = BeautifulSoup(response.text[:2_000_000], "html.parser")
    selectors = [
        ('meta[property="og:image"]', "content"),
        ('meta[property="og:image:secure_url"]', "content"),
        ('meta[name="twitter:image"]', "content"),
        ('meta[name="twitter:image:src"]', "content"),
    ]
    for selector, attribute in selectors:
        tag = soup.select_one(selector)
        if tag and tag.get(attribute):
            return urljoin(response.url, tag[attribute].strip())
    return ""


def _download_image(image_url):
    if not image_url:
        return ""
    response = requests.get(image_url, headers={"User-Agent": USER_AGENT}, timeout=25, stream=True)
    response.raise_for_status()
    content_type = response.headers.get("Content-Type", "").split(";")[0].lower()
    if not content_type.startswith("image/"):
        raise ValueError(f"Featured URL returned {content_type or 'non-image content'}")
    data = response.content
    if len(data) > 5 * 1024 * 1024:
        raise ValueError("Featured image exceeds 5 MB")
    digest = hashlib.sha256(image_url.encode()).hexdigest()[:16]
    target = IMAGE_DIR / f"{digest}.jpg"
    temp = IMAGE_DIR / f"{digest}.source"
    temp.write_bytes(data)
    try:
        with Image.open(temp) as image:
            image = image.convert("RGB")
            image.thumbnail((4096, 4096))
            image.save(target, "JPEG", quality=90, optimize=True)
    finally:
        temp.unlink(missing_ok=True)
    return str(target)


def get_featured_image(article_url, feed_image_url=""):
    image_url = ""
    try:
        image_url = _metadata_image(article_url)
    except Exception:
        image_url = ""
    image_url = image_url or feed_image_url or ""
    if not image_url:
        return "", ""
    try:
        return image_url, _download_image(image_url)
    except Exception:
        return image_url, ""


def _headers(ws):
    return {cell.value: cell.column for cell in ws[2] if cell.value}


def _open_queue(path):
    path = Path(path)
    if not path.exists():
        create_queue_workbook(path)
    wb = load_workbook(path)
    ws = wb[SHEET]
    columns = _headers(ws)
    missing = [header for header in HEADERS if header not in columns]
    if missing:
        raise ValueError("Excel queue is missing columns: " + ", ".join(missing))
    return wb, ws, columns


def add_article_to_queue(queue_path, title, article_url, source, published, tweet_text,
                         image_url, image_path, next_run, repeat_days):
    wb, ws, _ = _open_queue(queue_path)
    existing = {str(ws.cell(row, 5).value or "") for row in range(3, ws.max_row + 1)}
    if article_url in existing:
        raise ValueError("That article is already in the queue")
    ws.append([
        "YES", "POST", "QUEUED", tweet_text, article_url, title, source, published,
        image_url, image_path, next_run, repeat_days, "", "", "", 0
    ])
    row = ws.max_row
    for cell in ws[row]:
        cell.alignment = Alignment(vertical="top", wrap_text=True)
    ws.cell(row, 11).number_format = "yyyy-mm-dd hh:mm"
    ws.cell(row, 13).number_format = "yyyy-mm-dd hh:mm"
    wb.save(queue_path)
    return row


def load_queue_dataframe(path):
    wb, ws, _ = _open_queue(path)
    rows = list(ws.iter_rows(min_row=3, values_only=True))
    return pd.DataFrame(rows, columns=HEADERS)


def _x_clients():
    load_dotenv(ROOT / ".env")
    names = ["X_API_KEY", "X_API_SECRET", "X_ACCESS_TOKEN", "X_ACCESS_TOKEN_SECRET"]
    values = {name: os.getenv(name, "").strip() for name in names}
    missing = [name for name, value in values.items() if not value]
    if missing:
        raise ValueError("Missing X credentials in .env: " + ", ".join(missing))
    import tweepy
    auth = tweepy.OAuth1UserHandler(values["X_API_KEY"], values["X_API_SECRET"], values["X_ACCESS_TOKEN"], values["X_ACCESS_TOKEN_SECRET"])
    media_api = tweepy.API(auth)
    client = tweepy.Client(
        consumer_key=values["X_API_KEY"], consumer_secret=values["X_API_SECRET"],
        access_token=values["X_ACCESS_TOKEN"], access_token_secret=values["X_ACCESS_TOKEN_SECRET"]
    )
    return client, media_api


def _tweet_id(value):
    match = re.search(r"(?:status/)?(\d{5,})", str(value or ""))
    if not match:
        raise ValueError("REPOST mode requires an X post URL or ID in Article URL")
    return match.group(1)


def _publish_values(values, dry_run=False):
    mode = str(values.get("Mode") or "POST").upper()
    if mode == "POST":
        text = str(values.get("Tweet text") or "").strip()
        if not text:
            raise ValueError("Tweet text is blank")
        if dry_run:
            return "DRY RUN: would publish post", ""
        client, media_api = _x_clients()
        media_ids = None
        image_file = str(values.get("Image file") or "").strip()
        if image_file and Path(image_file).is_file():
            media = media_api.media_upload(filename=image_file)
            media_ids = [media.media_id]
        response = client.create_tweet(text=text, media_ids=media_ids, user_auth=True)
        post_id = str(response.data["id"])
        return f"POSTED: {post_id}", post_id
    if mode == "REPOST":
        post_id = _tweet_id(values.get("Article URL"))
        if dry_run:
            return f"DRY RUN: would repost {post_id}", post_id
        client, _ = _x_clients()
        client.retweet(post_id, user_auth=True)
        return f"REPOSTED: {post_id}", post_id
    raise ValueError("Mode must be POST or REPOST")


def _process_row(wb, ws, columns, row, dry_run=False, ignore_schedule=False):
    values = {header: ws.cell(row, columns[header]).value for header in HEADERS}
    if str(values["Enabled"] or "").upper() != "YES":
        return f"Row {row} is disabled."
    if str(values["Status"] or "").upper() not in {"QUEUED", "RETRY"} and not ignore_schedule:
        return f"Row {row} is not queued."
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    next_run = values["Next run (UTC)"]
    if not ignore_schedule and isinstance(next_run, datetime) and next_run > now:
        return f"Row {row} is not due yet."
    try:
        result, post_id = _publish_values(values, dry_run)
        if dry_run:
            return f"Row {row}: {result}"
        repeat_days = int(values["Repeat every days"] or 0)
        ws.cell(row, columns["Last run (UTC)"]).value = now
        ws.cell(row, columns["Last result"]).value = result
        ws.cell(row, columns["X Post ID"]).value = post_id
        ws.cell(row, columns["Times posted"]).value = int(values["Times posted"] or 0) + 1
        if repeat_days > 0 and str(values["Mode"]).upper() == "POST":
            ws.cell(row, columns["Next run (UTC)"]).value = now + timedelta(days=repeat_days)
            ws.cell(row, columns["Status"]).value = "QUEUED"
        else:
            ws.cell(row, columns["Status"]).value = "POSTED"
            ws.cell(row, columns["Enabled"]).value = "NO"
        wb.save(ws.parent._archive.filename if getattr(ws.parent, "_archive", None) else DEFAULT_QUEUE)
        return f"Row {row}: {result}"
    except Exception as exc:
        if not dry_run:
            ws.cell(row, columns["Status"]).value = "RETRY"
            ws.cell(row, columns["Last run (UTC)"]).value = now
            ws.cell(row, columns["Last result"]).value = f"ERROR: {type(exc).__name__}: {exc}"[:500]
        raise


def process_due_rows(path, dry_run=False):
    wb, ws, columns = _open_queue(path)
    messages = []
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    changed = False
    for row in range(3, ws.max_row + 1):
        enabled = str(ws.cell(row, columns["Enabled"]).value or "").upper() == "YES"
        status = str(ws.cell(row, columns["Status"]).value or "").upper()
        next_run = ws.cell(row, columns["Next run (UTC)"]).value
        if enabled and status in {"QUEUED", "RETRY"} and (not isinstance(next_run, datetime) or next_run <= now):
            try:
                values = {header: ws.cell(row, columns[header]).value for header in HEADERS}
                result, post_id = _publish_values(values, dry_run)
                messages.append(f"Row {row}: {result}")
                if not dry_run:
                    repeat_days = int(values["Repeat every days"] or 0)
                    ws.cell(row, columns["Last run (UTC)"]).value = now
                    ws.cell(row, columns["Last result"]).value = result
                    ws.cell(row, columns["X Post ID"]).value = post_id
                    ws.cell(row, columns["Times posted"]).value = int(values["Times posted"] or 0) + 1
                    if repeat_days > 0 and str(values["Mode"]).upper() == "POST":
                        ws.cell(row, columns["Next run (UTC)"]).value = now + timedelta(days=repeat_days)
                        ws.cell(row, columns["Status"]).value = "QUEUED"
                    else:
                        ws.cell(row, columns["Status"]).value = "POSTED"
                        ws.cell(row, columns["Enabled"]).value = "NO"
                    changed = True
            except Exception as exc:
                messages.append(f"Row {row}: ERROR: {exc}")
                if not dry_run:
                    ws.cell(row, columns["Status"]).value = "RETRY"
                    ws.cell(row, columns["Last run (UTC)"]).value = now
                    ws.cell(row, columns["Last result"]).value = f"ERROR: {type(exc).__name__}: {exc}"[:500]
                    changed = True
    if changed:
        wb.save(path)
    return messages


def publish_specific_row(path, row, dry_run=False):
    wb, ws, columns = _open_queue(path)
    if row < 3 or row > ws.max_row:
        raise ValueError("That Excel row does not exist")
    values = {header: ws.cell(row, columns[header]).value for header in HEADERS}
    result, post_id = _publish_values(values, dry_run)
    if not dry_run:
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        ws.cell(row, columns["Last run (UTC)"]).value = now
        ws.cell(row, columns["Last result"]).value = result
        ws.cell(row, columns["X Post ID"]).value = post_id
        ws.cell(row, columns["Times posted"]).value = int(values["Times posted"] or 0) + 1
        repeat_days = int(values["Repeat every days"] or 0)
        if repeat_days > 0 and str(values["Mode"]).upper() == "POST":
            ws.cell(row, columns["Next run (UTC)"]).value = now + timedelta(days=repeat_days)
            ws.cell(row, columns["Status"]).value = "QUEUED"
        else:
            ws.cell(row, columns["Status"]).value = "POSTED"
            ws.cell(row, columns["Enabled"]).value = "NO"
        wb.save(path)
    return f"Row {row}: {result}"
